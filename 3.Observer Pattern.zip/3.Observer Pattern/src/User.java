public class User {
    private String name;
    private int age;
    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void getNotification(String message) {
        System.out.println("To: " + name + ": " + message);
    }

    public void subscribe(Channel c) {
        c.addUser(this);
        System.out.println("Subscribed Successfully");
    }

    public void unsubscribe(Channel c) {
        c.removeUser(this);
        System.out.println("Unsubscribed Successfully");
    }
}
