
public class Main {
    public static void main(String[] args) {
        User a = new User("Bob", 20);
        User b = new User("John", 30);
        User c = new User("Jane", 40);
        User d = new User("Mary", 50);
        User e = new User("Joe", 60);
        User f = new User("Yane", 70);

        Channel c1 = new Channel("International News");
        Channel c2 = new Channel("Sports News");
        Channel c3 = new Channel("Miscellaneous");

        a.subscribe(c2);
        a.subscribe(c3);
        b.subscribe(c1);
        c.subscribe(c1);

        c1.notify("War stops in Middle East.");

    }
}