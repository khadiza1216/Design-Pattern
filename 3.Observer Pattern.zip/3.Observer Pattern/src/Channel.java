import java.util.ArrayList;

public class Channel {
    private String channelName;
    private ArrayList<User> subscribers;

    public Channel(String channelName) {
        this.subscribers = new ArrayList<>();
        this.channelName = channelName;
    }

    public void notify(String message) {
        message = "From: " + this.channelName + ": " + message;
        for (User user : subscribers) {
            user.getNotification(message);
        }
    }

    public void addUser(User user) {
        if (!subscribers.contains(user)) {
            this.subscribers.add(user);
        }
    }

    public void removeUser(User user) {
        this.subscribers.remove(user);
    }
}
